package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.myapplication.ui.mainactivity2.MainActivity2Fragment;

import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {
    RecyclerView recyclerView;
    productAdapter adapter;

    List<product> productList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity2_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, MainActivity2Fragment.newInstance())
                    .commitNow();

            productList=new ArrayList<>();

            recyclerView=(RecyclerView) findViewById(R.id.recyclerview);
            recyclerView.setHasFixedSize(true);

            recyclerView.setLayoutManager(new LinearLayoutManager(this));

            productList.add(
                    new product(
                            1,
                            "Ruffle Sleeve Floral Dress",
                            "dress",
                            600,
                            R.drawable.dress1));

            productList.add(
                    new product(
                            2,
                            "Floral Print Sleeveless Dress",
                            "dress",
                            900,
                            R.drawable.dress2));

            productList.add(
                    new product(
                            3,
                            "Perceptions - Floral Print Capelet Dress",
                            "dress",
                            1500,
                            R.drawable.dress3));



            adapter= new productAdapter(this,productList);
            recyclerView.setAdapter(adapter);
        }
    }
}
