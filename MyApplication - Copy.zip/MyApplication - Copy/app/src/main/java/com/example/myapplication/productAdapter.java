package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.zip.Inflater;

public class productAdapter extends RecyclerView.Adapter<productAdapter.productviewholder>{

    private Context mCtx;
    private List<product> productList;

    public productAdapter(Context mCtx, List<product> productList) {
        this.mCtx = mCtx;
        this.productList = productList;
    }

    @NonNull
    @Override
    public productviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater= LayoutInflater.from(mCtx);
        View view= inflater.inflate(R.layout.list_layout,null);
        productviewholder Holder= new productviewholder(view);
        return Holder;
    }

    @Override
    public void onBindViewHolder(@NonNull productviewholder holder, int position) {
        product product=productList.get(position);
        holder.textviewTitle.setText(product.getTitle());
        holder.textviewCategory.setText(product.getCategory());
        holder.textviewPrice.setText(String.valueOf(product.getPrice()));
        holder.imageView.setImageDrawable(mCtx.getResources().getDrawable(product.getImage()));

    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    class productviewholder extends RecyclerView.ViewHolder{

        ImageView imageView;
        TextView textviewTitle,textviewCategory,textviewPrice;

        public productviewholder(@NonNull View itemView) {
            super(itemView);

            imageView=  itemView.findViewById(R.id.imageView2);
            textviewTitle=itemView.findViewById(R.id.textView);
            textviewCategory=itemView.findViewById(R.id.textView3);
            textviewPrice=itemView.findViewById(R.id.textView2);
        }
    }


}
