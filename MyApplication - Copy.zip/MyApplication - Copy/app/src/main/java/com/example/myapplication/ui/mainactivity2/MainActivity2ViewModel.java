package com.example.myapplication.ui.mainactivity2;

import androidx.lifecycle.ViewModel;

public class MainActivity2ViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
