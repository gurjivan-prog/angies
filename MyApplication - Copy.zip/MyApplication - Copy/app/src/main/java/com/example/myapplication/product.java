package com.example.myapplication;

public class product {
   private int id;
   private String title ,category;
   private double price;
   private int image;

    public product(int id, String title, String category, double price, int image) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.price = price;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getCategory() {
        return category;
    }

    public double getPrice() {
        return price;
    }

    public int getImage() {
        return image;
    }
}
